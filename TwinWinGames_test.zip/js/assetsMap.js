export const assetsMap = {
	sprites:[
		{name: "symbol0", url: "../assets/0.jpg"},
		{name: "symbol1", url: "../assets/1.jpg"},
		{name: "symbol2", url: "../assets/2.jpg"},
		{name: "symbol3", url: "../assets/3.jpg"},
		{name: "symbol4", url: "../assets/4.jpg"},
		{name: "symbol5", url: "../assets/5.jpg"},
		{name: "symbol6", url: "../assets/6.jpg"},
		{name: "symbol7", url: "../assets/7.jpg"},
		{name: "symbol8", url: "../assets/8.jpg"},
		{name: "symbol9", url: "../assets/9.jpg"},
		{name: "symbol10", url: "../assets/10.jpg"},
		{name: "symbol11", url: "../assets/11.jpg"},

	]
}